import streamlit as st
import numpy as np
import itertools
import plotly.graph_objects as go
import time

def tour_length(pts, order):
    d = 0.0
    for i in range(len(order)):
        a = pts[order[i]]
        b = pts[order[(i+1)%len(order)]]
        d += np.linalg.norm(a-b)
    return d

def brute_force_tsp(pts):
    n = len(pts)
    best = None
    best_len = float("inf")
    for perm in itertools.permutations(range(1,n)):  # fijar 0 como origen
        order = (0,) + perm
        L = tour_length(pts, order)
        if L < best_len:
            best_len, best = L, order
    return best, best_len

def nn_tsp(pts):
    n = len(pts)
    unvis = set(range(1,n))
    order = [0]
    while unvis:
        last = order[-1]
        nxt = min(unvis, key=lambda j: np.linalg.norm(pts[last]-pts[j]))
        order.append(nxt)
        unvis.remove(nxt)
    return order, tour_length(pts, order)

def plot_tour(pts, order, title):
    xs = [pts[i][0] for i in order] + [pts[order[0]][0]]
    ys = [pts[i][1] for i in order] + [pts[order[0]][1]]
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=pts[:,0], y=pts[:,1], mode="markers", name="Ciudades"))
    fig.add_trace(go.Scatter(x=xs, y=ys, mode="lines+markers", name="Tour"))
    fig.update_layout(title=title, height=520, margin=dict(l=0,r=0,t=40,b=0))
    return fig

def view():
    st.header("TSP: Fuerza Bruta vs Vecino Más Cercano")
    n = st.slider("Número de ciudades (bruta ≲ 10)", 5, 10, 8)
    seed = st.number_input("Semilla", 0, 9999, 42)
    rng = np.random.default_rng(int(seed))
    pts = rng.random((n,2))*100

    c1, c2 = st.columns(2)
    with c1:
        if st.button("Ejecutar fuerza bruta"):
            t0 = time.perf_counter()
            order_bf, len_bf = brute_force_tsp(pts)
            t1 = time.perf_counter()
            st.info(f"Bruta: longitud={len_bf:.2f} • tiempo={(t1-t0):.3f}s")
            st.plotly_chart(plot_tour(pts, order_bf, "Óptimo (Bruta)"), use_container_width=True)
    with c2:
        if st.button("Ejecutar heurística (Vecino más cercano)"):
            t0 = time.perf_counter()
            order_nn, len_nn = nn_tsp(pts)
            t1 = time.perf_counter()
            st.info(f"NN: longitud={len_nn:.2f} • tiempo={(t1-t0):.3f}s")
            st.plotly_chart(plot_tour(pts, order_nn, "Aproximado (Nearest Neighbor)"), use_container_width=True)

    st.markdown("""
**Fuerza bruta** explora **n!** tours; la heurística corre en **O(n²)** y suele acercarse, pero no garantiza óptimo.
""")
