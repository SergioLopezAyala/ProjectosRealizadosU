import streamlit as st
import numpy as np
import plotly.graph_objects as go
import time

def solve_k_queens(k, max_frames=1200):
    N = k
    steps = []
    sol_cols = [-1] * k
    backtracks = 0

    def append_step():
        if not steps or steps[-1] != sol_cols[:]:
            if len(steps) < max_frames:
                steps.append(sol_cols[:])

    def bt(r, cols, diag, anti):
        nonlocal backtracks
        if r == k:
            append_step()
            return True
        mask = ((1 << N) - 1) & ~(cols | diag | anti)
        while mask:
            p = mask & -mask
            c = p.bit_length() - 1
            sol_cols[r] = c
            append_step()
            if bt(r + 1, cols | p, (diag | p) << 1, (anti | p) >> 1):
                return True
            sol_cols[r] = -1
            backtracks += 1
            append_step()
            mask ^= p
        return False

    bt(0, 0, 0, 0)
    solution = [(r, c) for r, c in enumerate(sol_cols) if c != -1]
    return steps, solution, backtracks, N

def chessboard_heatmap(N):
    z = np.fromfunction(lambda r, c: (r + c) % 2, (N, N))
    colorscale = [[0.0, "#EEEED2"], [1.0, "#769656"]]
    return go.Heatmap(
        z=z,
        colorscale=colorscale,
        showscale=False,
        zmin=0,
        zmax=1,
        hoverinfo="skip",
        hovertemplate=None
    )

def board_fig(positions, N):
    fig = go.Figure(data=[chessboard_heatmap(N)])
    fig.update_xaxes(visible=False, range=[-0.5, N - 0.5])
    fig.update_yaxes(visible=False, range=[N - 0.5, -0.5])
    h = 420 if N <= 5 else 520
    fig.update_layout(margin=dict(l=0, r=0, t=0, b=0), height=h, hovermode=False)
    if positions:
        xs = [c for (_, c) in positions]
        ys = [r for (r, _) in positions]
        fig.add_trace(go.Scatter(
            x=xs,
            y=ys,
            mode="text",
            text=["♛"] * len(xs),
            textfont=dict(size=46 if N <= 5 else 42, color="black"),
            textposition="middle center",
            hoverinfo="skip",
            showlegend=False
        ))
    return fig

def view():
    st.header("N‑Reinas con tablero ajustado")
    k = st.slider("Número de reinas (y tamaño del tablero)", 4, 8, 8)

    if "kqueens_run_id" not in st.session_state:
        st.session_state["kqueens_run_id"] = 0

    placeholder = st.empty()
    placeholder.plotly_chart(board_fig([], k), use_container_width=True, key=f"kq-init-{k}")

    if st.button("Resolver y animar"):
        st.session_state["kqueens_run_id"] += 1
        run_id = st.session_state["kqueens_run_id"]

        t0 = time.perf_counter()
        steps, solution, backtracks, N = solve_k_queens(k)
        t1 = time.perf_counter()

        if len(solution) != k:
            st.error("No se encontró solución.")
            return

        stride = max(1, len(steps) // 400)
        frame_index = 0
        for s in steps[::stride]:
            pos = [(r, c) for r, c in enumerate(s) if c != -1]
            fig = board_fig(pos, N)
            placeholder.plotly_chart(fig, use_container_width=True, key=f"kq-{run_id}-{k}-{frame_index}")
            frame_index += 1

        fig = board_fig(solution, N)
        placeholder.plotly_chart(fig, use_container_width=True, key=f"kq-{run_id}-{k}-final")

        st.info(f"Backtracking: {backtracks} • Pasos de animación: {len(steps)} • Tiempo: {(t1 - t0)*1000:.1f} ms")
