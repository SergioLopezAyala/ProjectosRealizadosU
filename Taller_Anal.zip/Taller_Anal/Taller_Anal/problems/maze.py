import streamlit as st
import numpy as np
from collections import deque
import plotly.graph_objects as go
import time

def grid_fig(grid, start, goal, visit=None, path=None):
    h, w = grid.shape
    z = np.where(grid==1, 0.3, 1.0)
    fig = go.Figure(data=go.Heatmap(z=z, showscale=False))
    fig.update_xaxes(visible=False, range=[-0.5, w-0.5])
    fig.update_yaxes(visible=False, range=[h-0.5, -0.5])

    # 👇 Antes: fig.add_shape("rect", ...)
    fig.add_shape(type="rect", x0=start[1]-0.5, x1=start[1]+0.5, y0=start[0]-0.5, y1=start[0]+0.5)
    fig.add_shape(type="rect", x0=goal[1]-0.5,  x1=goal[1]+0.5,  y0=goal[0]-0.5,  y1=goal[0]+0.5)

    fig.add_trace(go.Scatter(x=[start[1], goal[1]], y=[start[0], goal[0]],
                             mode="markers", marker=dict(size=14), showlegend=False))
    if visit:
        xs, ys = zip(*[(c[1], c[0]) for c in visit])
        fig.add_trace(go.Scatter(x=xs, y=ys, mode="markers",
                                 marker=dict(size=6, opacity=0.6), name="Visitados"))
    if path:
        xs, ys = zip(*[(c[1], c[0]) for c in path])
        fig.add_trace(go.Scatter(x=xs, y=ys, mode="lines+markers",
                                 name="Camino", marker=dict(size=8)))
    fig.update_layout(margin=dict(l=0,r=0,t=0,b=0), height=520)
    return fig

def neighbors(r, c, h, w):
    for dr, dc in [(1,0),(-1,0),(0,1),(0,-1)]:
        nr, nc = r+dr, c+dc
        if 0 <= nr < h and 0 <= nc < w:
            yield nr, nc

def bfs(grid, start, goal):
    h, w = grid.shape
    q = deque([start])
    prev = {start: None}
    visit_order = [start]
    while q:
        cur = q.popleft()
        if cur == goal:
            break
        for nr, nc in neighbors(*cur, h, w):
            if grid[nr, nc] == 0 and (nr, nc) not in prev:
                prev[(nr, nc)] = cur
                q.append((nr, nc))
                visit_order.append((nr, nc))
    # reconstruir camino
    path = []
    cur = goal
    if cur in prev:
        while cur:
            path.append(cur)
            cur = prev[cur]
        path.reverse()
    return visit_order, path

def dfs(grid, start, goal):
    h, w = grid.shape
    stack = [start]
    prev = {start: None}
    visit_order = [start]
    while stack:
        cur = stack.pop()
        if cur == goal:
            break
        for nr, nc in neighbors(*cur, h, w):
            if grid[nr, nc] == 0 and (nr, nc) not in prev:
                prev[(nr, nc)] = cur
                stack.append((nr, nc))
                visit_order.append((nr, nc))
    path = []
    cur = goal
    if cur in prev:
        while cur:
            path.append(cur)
            cur = prev[cur]
        path.reverse()
    return visit_order, path

def animate(grid, start, goal, visit, path):
    placeholder = st.empty()
    # visita progresiva
    step = max(1, len(visit)//200)  # limitar frames
    for i in range(0, len(visit), step):
        fig = grid_fig(grid, start, goal, visit[:i], None)
        placeholder.plotly_chart(fig, use_container_width=True)
        time.sleep(0.01)
    # camino final
    fig = grid_fig(grid, start, goal, visit, path)
    placeholder.plotly_chart(fig, use_container_width=True)

def view():
    st.header("Laberinto: BFS (anchura) vs DFS (profundidad)")
    c1, c2, c3 = st.columns(3)
    with c1:
        h = st.slider("Alto", 10, 50, 25)
    with c2:
        w = st.slider("Ancho", 10, 50, 35)
    with c3:
        dens = st.slider("Densidad de obstáculos", 0.0, 0.5, 0.25, 0.01)

    rng = np.random.default_rng(42)
    grid = (rng.random((h, w)) < dens).astype(int)
    start = (0, 0)
    goal = (h-1, w-1)
    grid[start] = 0
    grid[goal]  = 0

    algo = st.radio("Algoritmo", ["BFS (camino más corto)", "DFS (algún camino)"], horizontal=True)
    if st.button("Ejecutar"):
        t0 = time.perf_counter()
        if "BFS" in algo:
            visit, path = bfs(grid, start, goal)
        else:
            visit, path = dfs(grid, start, goal)
        t1 = time.perf_counter()
        st.info(f"Nodos visitados: {len(visit)} • Longitud del camino: {len(path) if path else '—'} • Tiempo: {(t1-t0)*1000:.2f} ms")
        animate(grid, start, goal, visit, path)

    st.markdown("""
**Notas**:  
- En grafos no ponderados, *BFS* encuentra un **camino más corto** si existe.  
- *DFS* suele visitar menos vecinos en anchura pero puede desviarse y tardar más en hallar la meta, o no hallar el camino si hay restricciones de profundidad.  
Complejidad en ambos: **O(V+E)**.
""")
