import streamlit as st
from dataclasses import dataclass
from typing import List, Dict
import os
import time

@dataclass
class Event:
    year: int
    title: str
    desc: str

DATA: Dict[str, Dict] = {
    "Laberinto (BFS/DFS)": {
        "image": "maze.jpg",
        "history": """La resolución sistemática de laberintos se remonta al siglo XIX, cuando los recorridos manuales empezaron a documentarse como procedimientos repetibles para no perderse en redes de pasillos. El paso decisivo fue comprender que un laberinto podía verse como un grafo: intersecciones como vértices y pasillos como aristas. Este cambio de perspectiva permitió abstraer cualquier rompecabezas físico a una estructura matemática general y comparar estrategias de recorrido.

La búsqueda en profundidad explora una ruta hasta el límite y solo entonces retrocede para probar alternativas. Esta idea cristaliza el principio de compromiso local: avanzar con decisión, asumir temporalmente una elección y deshacerla si no conduce a una solución. La búsqueda en anchura expande por capas y visita primero todos los estados a un salto del origen, luego a dos saltos y así sucesivamente. Esta política añade una garantía poderosa en grafos no ponderados: el primer encuentro con el objetivo produce un camino de longitud mínima. Con el surgimiento de la computación moderna, ambas técnicas se integraron al repertorio básico de análisis de grafos, verificación de conectividad, caminos más cortos en entornos sin pesos, y como base de métodos más sofisticados en inteligencia artificial.

La elección entre profundidad y anchura no es una decisión estética sino de objetivo y recursos. La profundidad tiende a tener una huella de memoria pequeña cuando la ramificación es amplia y las soluciones son profundas, y es útil para inspeccionar la estructura interna de un problema. La anchura consume más memoria pero ofrece soluciones mínimas en número de pasos y un orden de descubrimiento por capas útil para medir accesibilidad y expansión. En redes sociales, epidemiología computacional y sistemas de recomendación, la expansión por niveles permite caracterizar proximidades y fronteras de influencia. En verificación de software, análisis de dependencias y generación de estructuras, la exploración profunda revela ciclos, clasifica aristas y habilita ordenaciones topológicas. Ambas técnicas conservan la virtud de la simplicidad con complejidad lineal en el tamaño del grafo cuando se emplean representaciones adecuadas.""",
        "events": [
            Event(
                1870,
                "Trémaux",
                "Charles Pierre Trémaux describió un método práctico para resolver laberintos que consistía en marcar intersecciones y evitar repetir caminos. El procedimiento garantiza que, con memoria limitada y reglas simples, el explorador termina por encontrar la salida o demostrar que no existe. Este enfoque antecede la formalización algorítmica de la búsqueda en profundidad y muestra que la disciplina de marcar decisiones y retroceder ordenadamente puede convertir un entorno confuso en una exploración sistemática."
            ),
            Event(
                1959,
                "Formalización de BFS",
                "La comunidad de teoría de grafos adoptó la expansión por capas como procedimiento canónico para recorrer grafos no ponderados. El algoritmo coloca el origen en una cola, visita sus vecinos, y luego los vecinos de esos vecinos, manteniendo distancias mínimas al origen. Esta política produce árboles de expansión por niveles con propiedades métricas claras y una prueba inmediata de corrección para encontrar caminos con el menor número de aristas."
            ),
            Event(
                1970,
                "Consolidación en algoritmia",
                "Con la estandarización de listas de adyacencia y matrices de adyacencia, BFS y DFS se integraron al temario central de estructuras de datos. DFS aportó un marco natural para clasificar aristas según tiempos de entrada y salida, detectar componentes fuertemente conexas y producir ordenaciones topológicas en grafos acíclicos dirigidos. BFS se volvió la herramienta de referencia para distancias discretas, propagación y enumeración por niveles en grandes redes."
            )
        ]
    },
    "N‑Reinas": {
        "image": "nqueens.jpg",
        "history": """El rompecabezas de 8 reinas planteó en el siglo XIX un desafío elegante: ubicar ocho reinas en un tablero de 8×8 sin que se ataquen por filas, columnas o diagonales. La generalización a n‑reinas transformó el acertijo en una familia paramétrica y reveló su naturaleza combinatoria. La computadora convirtió el problema en un laboratorio ideal para la técnica de backtracking: construir soluciones paso a paso, detectar violaciones temprano y deshacer decisiones cuando se agotan las opciones.

La evolución moderna del problema introdujo representaciones compactas y ordenaciones inteligentes de decisiones. Las máscaras de bits permiten verificar ataques con operaciones de desplazamiento y conjunciones a nivel de entero, reduciendo el costo por paso y aumentando la profundidad alcanzable en tiempos acotados. El número de soluciones y su estructura han sido objeto de estudios enumerativos y experimentos computacionales. La lección central trasciende el rompecabezas: la representación de restricciones y la calidad de la poda son tan determinantes como la potencia bruta de cómputo. En formación de ingenieros y científicos de datos, n‑reinas ofrece una ventana clara a la relación entre modelado, búsqueda y eficiencia.""",
        "events": [
            Event(
                1848,
                "Publicación de 8 reinas",
                "Max Bezzel difundió el reto de ubicar ocho reinas en el tablero estándar. La formulación capturó la imaginación de matemáticos y aficionados y generó una tradición de soluciones y variantes impresas en periódicos y almanaques científicos."
            ),
            Event(
                1850,
                "Generalización a n‑reinas",
                "Franz Nauck propuso la versión para n reinas en tableros n×n y publicó construcciones y conteos. Esta generalización abrió la puerta a argumentos por inducción, familias de patrones y comparaciones entre estrategias de búsqueda conforme crecía el tamaño del espacio de estados."
            ),
            Event(
                1970,
                "Backtracking y podas modernas",
                "La adopción de bitmasks para columnas y diagonales y la selección cuidadosa del orden de colocación se volvieron prácticas estándar. El problema se consolidó como ejemplo pedagógico para ilustrar cómo la poda reduce el crecimiento explosivo del árbol de búsqueda y habilita resolver instancias grandes con recursos modestos."
            )
        ]
    },
    "Agente Viajero (TSP)": {
        "image": "tsp.jpg",
        "history": """El agente viajero pide encontrar un recorrido de costo mínimo que visite una vez cada ciudad y regrese al origen. La conexión con los ciclos hamiltonianos sugiere su dificultad: el número de posibles tours crece factorialmente. A mediados del siglo XX, el problema se convirtió en vitrina de la optimización combinatoria y en plataforma para probar métodos exactos y heurísticos.

El uso de programación lineal y cortes poliedrales mostró que, incluso en espacios enormes, la estructura geométrica de las soluciones podía explotarse para acotar óptimos y guiar la búsqueda. La programación dinámica de Held y Karp ofreció un enfoque con complejidad exponencial más ordenada que la fuerza bruta y estableció límites teóricos que siguen siendo referencia. Con el paso de las décadas, la combinación de branch‑and‑cut, relajaciones, heurísticas de vecindarios locales y técnicas numéricas permitió resolver instancias de gran escala. Al mismo tiempo floreció un ecosistema de heurísticas rápidas de extraordinaria calidad para aplicaciones cotidianas, desde logística y diseño de circuitos hasta planificación de rutas en robótica. La lección metodológica es doble: la modelación correcta revela estructura explotable, y la mezcla de exactitud con heurística produce soluciones de alta calidad en tiempos realistas.""",
        "events": [
            Event(
                1857,
                "Ciclos hamiltonianos",
                "El juego icosiano y los estudios de William Rowan Hamilton introdujeron el concepto de ciclos que visitan cada vértice una única vez, sentando las bases conceptuales para problemas de recorrido global como el TSP."
            ),
            Event(
                1954,
                "Programación lineal y cortes",
                "Dantzig, Fulkerson y Johnson resolvieron una instancia de 49 ciudades mediante relajaciones lineales y cortes válidos que eliminaban fracciones indeseadas. Este trabajo inauguró una tradición de explotar la geometría del politopo del TSP."
            ),
            Event(
                1962,
                "Programación dinámica de Held–Karp",
                "Richard Bellman y, posteriormente, Held y Karp, desarrollaron una formulación de programación dinámica basada en subconjuntos que, aunque exponencial, mejoró la comprensión estructural del problema y se convirtió en un límite de referencia al comparar algoritmos."
            )
        ]
    },
    "Mochila 0‑1": {
        "image": "knapsack.jpg",
        "history": """La mochila 0‑1 formaliza el dilema de seleccionar objetos con peso y valor para maximizar la utilidad sin exceder una capacidad. El espacio de subconjuntos crece exponencialmente, pero la programación dinámica demostró que cuando la capacidad se considera en valor absoluto, el problema puede resolverse en tiempo proporcional al producto del número de ítems y la capacidad, un resultado pseudo‑polinómico.

El reconocimiento de su NP‑completitud impulsó el desarrollo de técnicas de aproximación con garantías y de esquemas plenamente polinómicos que permiten controlar el compromiso entre precisión y tiempo. La ubicuidad de la mochila en asignación de presupuestos, cartera de inversiones, corte de materiales y planificación con recursos limitados la convirtió en caso de estudio para comparar fuerza bruta, DP, branch‑and‑bound y formulaciones de programación entera. La lección transversal es que el parámetro que se elige como “tamaño” de la entrada determina la frontera práctica entre intractabilidad teórica y eficiencia empírica.""",
        "events": [
            Event(
                1950,
                "Programación dinámica",
                "Richard Bellman popularizó un enfoque que descompone la decisión global en subproblemas por capacidad, acumulando mejores valores hasta alcanzar el presupuesto disponible. Este método reveló la estructura incremental del problema y habilitó soluciones eficientes en muchos escenarios reales."
            ),
            Event(
                1972,
                "NP‑completitud",
                "La clasificación de la variante de decisión como NP‑completa cimentó la intuición de que no existe, salvo colapsos en complejidad, un algoritmo polinómico que resuelva toda instancia parametrizada por el tamaño de su representación binaria."
            ),
            Event(
                1990,
                "Aproximación eficiente",
                "Los esquemas totalmente polinómicos de aproximación (FPTAS) demostraron que es posible obtener soluciones arbitrariamente cercanas al óptimo en tiempo polinómico en el tamaño de la entrada y en 1/ε, ofreciendo una alternativa práctica entre exactitud y rendimiento."
            )
        ]
    },
    "Coloreado de Grafos": {
        "image": "coloring.jpg",
        "history": """El coloreado de grafos asigna colores a vértices de modo que adyacentes no compartan color, buscando minimizar la cantidad usada. La famosa conjetura de los cuatro colores para mapas planos catalizó el estudio de técnicas combinatorias asistidas por cómputo y abrió un debate sobre el estatuto de las demostraciones apoyadas en cálculos extensos.

Más allá del plano, calcular el número cromático es una tarea dura. La respuesta práctica ha sido una rica caja de herramientas: estrategias greedy con ordenaciones adaptativas, el criterio de saturación de DSATUR para elegir el siguiente vértice a colorear, y métodos exactos basados en programación entera y búsqueda con podas. En aplicaciones, el coloreado modela incompatibilidades: asignación de horarios sin traslapes, frecuencias de radio que no interfieran, y registros de variables en compiladores. La tensión entre optimalidad y tiempo real conduce a soluciones híbridas donde buenas heurísticas, ajustadas a la estructura del grafo, resuelven problemas a gran escala con calidad suficiente para la práctica.""",
        "events": [
            Event(
                1852,
                "Conjetura de 4 colores",
                "Francis Guthrie formuló la pregunta de si cuatro colores bastan para colorear cualquier mapa plano sin que regiones adyacentes compartan color. La conjetura marcó el inicio de una saga de intentos y refinamientos teóricos."
            ),
            Event(
                1976,
                "Prueba asistida por computadora",
                "Appel y Haken presentaron una demostración que descomponía el problema en miles de configuraciones verificadas por computadora. El resultado inauguró una era de colaboración estrecha entre razonamiento humano y cálculo automatizado."
            ),
            Event(
                1990,
                "Heurísticas y métodos exactos",
                "El desarrollo de DSATUR, variantes greedy con ordenación dinámica y técnicas de branch‑and‑bound fortaleció la práctica del coloreado en grafos generales y aplicados, con implementaciones capaces de manejar redes reales de gran tamaño."
            )
        ]
    },
    "Sudoku": {
        "image": "sudoku.jpg",
        "history": """El Sudoku, heredero de puzzles numéricos como Number Place, se convirtió en un fenómeno cultural a principios del siglo XXI. Su estructura impone restricciones locales simples con efectos globales: cada fila, columna y subcuadrícula debe contener los dígitos del 1 al 9 sin repetición. Esta combinación de reglas claras y profundidad combinatoria lo vuelve ideal para explorar técnicas de inferencia y búsqueda.

Dos enfoques han dominado su tratamiento algorítmico. El primero utiliza backtracking con heurísticas inspiradas en las técnicas humanas: buscar celdas con pocas opciones, propagar deducciones y aplicar patrones como pares desnudos o intersecciones bloqueadas. El segundo reduce el problema a Exact Cover y emplea el Algoritmo X con danzas de enlaces, una estructura de datos que permite insertar y retirar opciones en tiempo muy bajo. Más allá de resolver, la generación de instancias con solución única y nivel de dificultad controlado es un desafío adicional con su propia dinámica algorítmica. El Sudoku sigue siendo un puente entre el placer del acertijo y el estudio formal de la satisfacción de restricciones.""",
        "events": [
            Event(
                1979,
                "Number Place",
                "Howard Garns publicó rompecabezas que fijaron el formato moderno: rejillas con pistas iniciales cuidadosamente escogidas para permitir una única solución alcanzable por deducciones lógicas."
            ),
            Event(
                1986,
                "Popularización en Japón",
                "La editorial Nikoli difundió el Sudoku con reglas claras y una estética uniforme, convirtiéndolo en una firma reconocible en revistas de pasatiempos y consolidando una comunidad de autores y solucionadores."
            ),
            Event(
                2000,
                "Difusión global",
                "Periódicos, sitios web y aplicaciones móviles llevaron el rompecabezas a audiencias masivas. Los solvers automáticos y los generadores de tableros evolucionaron en paralelo a las técnicas humanas, dando lugar a un intercambio continuo entre práctica y teoría."
            )
        ]
    }
}

def _show_image(img_name: str):
    path = os.path.join("assets", img_name)
    if os.path.exists(path):
        st.image(path, use_container_width=True)

def _event_tabs(events: List[Event], key_prefix: str):
    labels = [f"{e.year} · {e.title}" for e in events]
    tabs = st.tabs(labels)
    for i, t in enumerate(tabs):
        with t:
            st.subheader(f"{events[i].title} ({events[i].year})")
            st.write(events[i].desc)

def view():
    st.title("Historia")
    topic = st.selectbox("Tema", list(DATA.keys()), index=0, key="hist_topic_final")
    _show_image(DATA[topic]["image"])
    st.markdown(DATA[topic]["history"])
    st.divider()
    _event_tabs(DATA[topic]["events"], key_prefix=topic.replace(" ", "_"))
