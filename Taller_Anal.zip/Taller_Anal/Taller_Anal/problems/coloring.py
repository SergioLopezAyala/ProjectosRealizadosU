import streamlit as st
import networkx as nx
import numpy as np
import plotly.graph_objects as go
import time

def random_graph(n, p, seed=1):
    rng = np.random.default_rng(seed)
    G = nx.Graph()
    G.add_nodes_from(range(n))
    for i in range(n):
        for j in range(i+1,n):
            if rng.random() < p:
                G.add_edge(i,j)
    return G

def backtrack_color(G, k):
    colors = {}
    order = sorted(G.nodes(), key=lambda u: -G.degree[u])
    steps = []
    def ok(u, c):
        for v in G.neighbors(u):
            if colors.get(v) == c: return False
        return True
    def bt(i=0):
        if i == len(order): return True
        u = order[i]
        for c in range(k):
            if ok(u,c):
                colors[u]=c; steps.append(colors.copy())
                if bt(i+1): return True
                del colors[u]; steps.append(colors.copy())
        return False
    bt()
    return colors, steps

def plot_graph(G, colors=None):
    pos = nx.spring_layout(G, seed=2)
    xs, ys = [], []
    for (u,v) in G.edges():
        xs += [pos[u][0], pos[v][0], None]
        ys += [pos[u][1], pos[v][1], None]
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=xs, y=ys, mode="lines", line=dict(width=1), showlegend=False))
    node_x = [pos[u][0] for u in G.nodes()]
    node_y = [pos[u][1] for u in G.nodes()]
    texts = [f"{u}" for u in G.nodes()]
    marker = dict(size=18)
    if colors:
        marker["color"] = [colors.get(u, -1) for u in G.nodes()]
    fig.add_trace(go.Scatter(x=node_x, y=node_y, mode="markers+text", text=texts, textposition="top center",
                             marker=marker, showlegend=False))
    fig.update_layout(margin=dict(l=0,r=0,t=0,b=0), height=520)
    return fig

def view():
    st.header("Coloreado de Grafos (backtracking)")
    n = st.slider("Nodos", 4, 20, 10)
    p = st.slider("Prob. de arista", 0.0, 1.0, 0.25, 0.05)
    k = st.slider("Colores k", 2, 5, 3)
    G = random_graph(n, p)

    # contador para claves únicas
    if "coloring_run_id" not in st.session_state:
        st.session_state["coloring_run_id"] = 0

    if st.button("Colorear"):
        st.session_state["coloring_run_id"] += 1
        run_id = st.session_state["coloring_run_id"]

        colors, steps = backtrack_color(G, k)
        ph = st.empty()
        step_stride = max(1, len(steps)//200)
        for idx, c in enumerate(steps[::step_stride]):
            ph.plotly_chart(plot_graph(G, c), use_container_width=True)
            time.sleep(0.01)

        # usar el MISMO placeholder o asignar una key única
        ph.plotly_chart(
            plot_graph(G, colors),
            use_container_width=True,
            key=f"coloring-final-{run_id}"
        )
        st.info(f"Colores usados: {len(set(colors.values())) if colors else 0} (k={k}).")

    else:
        st.plotly_chart(
            plot_graph(G, None),
            use_container_width=True,
            key="coloring-initial"
        )
    st.markdown("Backtracking explora asignaciones; **exponencial** en el peor caso.")
