import streamlit as st
import numpy as np
import itertools
import time

def brute(items, W):
    n = len(items)
    bestV, bestS = 0, []
    for mask in range(1<<n):
        w = v = 0
        take = []
        for i in range(n):
            if mask & (1<<i):
                w += items[i][0]; v += items[i][1]; take.append(i)
        if w <= W and v > bestV:
            bestV, bestS = v, take
    return bestV, bestS

def dp(items, W):
    n = len(items)
    dp = [0]*(W+1)
    take = [[False]*(W+1) for _ in range(n)]
    for i,(wt,val) in enumerate(items):
        for cap in range(W, wt-1, -1):
            if dp[cap-wt] + val > dp[cap]:
                dp[cap] = dp[cap-wt] + val
                take[i][cap] = True
    # reconstruir
    cap = W; chosen=[]
    for i in range(n-1,-1,-1):
        if take[i][cap]:
            chosen.append(i); cap -= items[i][0]
    chosen.reverse()
    return dp[W], chosen

def view():
    st.header("Mochila 0‑1: Bruta vs Programación Dinámica")
    n = st.slider("Número de ítems", 6, 22, 16)
    W = st.slider("Capacidad", 10, 80, 40, 1)
    rng = np.random.default_rng(7)
    weights = rng.integers(1, 15, size=n)
    values  = rng.integers(1, 30, size=n)
    items = list(zip(weights, values))
    st.write("Ítems (peso, valor):", items)

    c1, c2 = st.columns(2)
    with c1:
        if st.button("Fuerza bruta (2^n)"):
            t0 = time.perf_counter()
            v, take = brute(items, W)
            t1 = time.perf_counter()
            st.info(f"Valor={v} • Tomados={take} • tiempo={(t1-t0):.3f}s")
    with c2:
        if st.button("DP (O(n·W))"):
            t0 = time.perf_counter()
            v, take = dp(items, W)
            t1 = time.perf_counter()
            st.info(f"Valor={v} • Tomados={take} • tiempo={(t1-t0):.3f}s")

    st.markdown("**Bruta**: O(2^n). **DP**: O(n·W) (pseudo‑polinómica).")
