import streamlit as st
from problems import maze, nqueens, tsp, knapsack, coloring
from problems import history

st.set_page_config(page_title="Algoritmos con Animación", layout="wide")

st.title("Visualizador de Algoritmos • Fuerza Bruta y Alternativas")
st.caption("Elige un problema, ajusta parámetros y mira la animación. Incluye comparadores de eficiencia y una página de historia.")

opcion = st.sidebar.selectbox(
    "Sección",
    [
        "Historia & Contexto",          # <-- nueva
        "Laberinto (BFS vs DFS)",
        "N-Reinas (Backtracking)",
        "Agente Viajero (TSP)",
        "Mochila 0-1",
        "Coloreado de Grafos"
    ],
)

if opcion == "Historia & Contexto":
    history.view()
elif opcion == "Laberinto (BFS vs DFS)":
    maze.view()
elif opcion == "N-Reinas (Backtracking)":
    nqueens.view()
elif opcion == "Agente Viajero (TSP)":
    tsp.view()
elif opcion == "Mochila 0-1":
    knapsack.view()
else:
    coloring.view()